API_URL = "https://wap.tplinkcloud.com"
APPTYPE = "Kasa_Android"
USERAGENT = "User-Agent: Dalvik/2.1.0 (Linux; U; Android 6.0.1; A0001 Build/M4B30X)"